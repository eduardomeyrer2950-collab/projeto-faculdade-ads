# Lista com os nomes dos meses  para a exibição final:
nomes_meses = [
    "janeiro", "fevereiro", "março", "abril", "maio", "junho",
    "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"
]

#  acumular os cálculos:
soma_temperaturas = 0.0
meses_escaldantes = 0

# Variáveis para encontrar a maior e menor temperatura (iniciadas com os extremos permitidos)
maior_temp = -61.0
mes_maior_temp = 0

menor_temp = 51.0
mes_menor_temp = 0

#  repetir a leitura para cada um dos 12 meses
for mes in range(1, 13):
    
    # Loop de validação: só quando digitar uma temperatura correta
    while True:
        print(f"Informe a temperatura máxima para o mês {mes} ({nomes_meses[mes-1]}):")
        temp = float(input())
        
        # Validação do intervalo de -60 a +50 graus
        if temp >= -60.0 and temp <= 50.0:
            break  # Dado válido, sai do loop de validação
        else:
            print("Erro! A temperatura deve estar entre -60 e +50 graus. Tente novamente.")

    # 1. Acumula para a média anual
    soma_temperaturas += temp

    # 2. Conta se o mês é escaldante (acima de 33 graus)
    if temp > 33.0:
        meses_escaldantes += 1

    # 3. Verifica se é a maior temperatura encontrada até agora
    if temp > maior_temp:
        maior_temp = temp
        mes_maior_temp = mes

    # 4. Verifica se é a menor temperatura encontrada até agora
    if temp < menor_temp:
        menor_temp = temp
        mes_menor_temp = mes

# Cálculos finais
media_anual = soma_temperaturas / 12

# Fim: Exibir os resultados na tela
print("\n--- ANALISE METEOROLOGICA DE 2021 ---")
print(f"Temperatura média máxima anual: {media_anual:.2f} ºC")
print(f"Quantidade de meses escaldantes: {meses_escaldantes}")
print(f"Mês mais escaldante do ano: {nomes_meses[mes_maior_temp - 1]} ({maior_temp} ºC)")
print(f"Mês menos quente do ano: {nomes_meses[mes_menor_temp - 1]} ({menor_temp} ºC)")
